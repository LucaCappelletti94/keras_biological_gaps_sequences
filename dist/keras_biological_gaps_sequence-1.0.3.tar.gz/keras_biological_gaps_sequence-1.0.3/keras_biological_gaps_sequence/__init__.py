from .biological_gaps_sequence import BiologicalGapsSequence

__all__ = [
    "BiologicalGapsSequence"
]