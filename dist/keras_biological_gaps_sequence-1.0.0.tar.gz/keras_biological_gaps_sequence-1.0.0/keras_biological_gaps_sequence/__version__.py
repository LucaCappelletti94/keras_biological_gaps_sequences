"""Current version of package keras_biological_gaps_sequences"""
__version__ = "1.0.0"