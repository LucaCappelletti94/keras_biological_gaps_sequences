"""Current version of package keras_biological_gaps_sequence"""
__version__ = "1.0.2"